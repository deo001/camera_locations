import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:get/get.dart';

class LocationController extends GetxController {
  final RxDouble latitude = 0.0.obs;
  final RxDouble longitude = 0.0.obs;
  final RxDouble altitude = 0.0.obs;
  final RxDouble accuracy = 0.0.obs;
  final RxDouble speed = 0.0.obs;
  final RxBool isLoading = false.obs;
  final RxBool hasLocation = false.obs;
  final RxString errorMessage = ''.obs;

  Future<void> getCurrentLocation() async {
    try {
      isLoading.value = true;
      hasLocation.value = false;
      errorMessage.value = '';

      final permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        final requested = await Geolocator.requestPermission();
        if (requested == LocationPermission.denied ||
            requested == LocationPermission.deniedForever) {
          errorMessage.value =
              'Location permission is required.\nGrant it in Settings.';
          isLoading.value = false;
          return;
        }
      }

      final position = await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(
          accuracy: LocationAccuracy.bestForNavigation,
          timeLimit: Duration(seconds: 30),
        ),
      );

      latitude.value = position.latitude;
      longitude.value = position.longitude;
      altitude.value = position.altitude;
      accuracy.value = position.accuracy;
      speed.value = position.speed;
      hasLocation.value = true;
    } catch (e) {
      debugPrint('Error getting location: $e');
      errorMessage.value = 'Could not get location: $e';
      hasLocation.value = false;
    } finally {
      isLoading.value = false;
    }
  }

  void clear() {
    latitude.value = 0.0;
    longitude.value = 0.0;
    altitude.value = 0.0;
    accuracy.value = 0.0;
    speed.value = 0.0;
    hasLocation.value = false;
    errorMessage.value = '';
  }
}
