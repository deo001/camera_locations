import 'dart:io';
import 'package:exif/exif.dart' as exif_dart;
import 'package:geolocator/geolocator.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';

class HomeController extends GetxController {
  final ImagePicker _picker = ImagePicker();

  final Rx<File?> capturedImage = Rx<File?>(null);
  final RxBool isLoading = false.obs;
  final Rx<Map<String, Object>> allAttributes = Rx<Map<String, Object>>({});

  // Real-time GPS (not from EXIF)
  final RxDouble gpsLatitude = 0.0.obs;
  final RxDouble gpsLongitude = 0.0.obs;
  final RxDouble gpsAltitude = 0.0.obs;
  final RxDouble gpsAccuracy = 0.0.obs;
  final RxBool hasGps = false.obs;
  final RxBool gpsLoading = false.obs;
  final RxString gpsError = ''.obs;

  Future<void> takePhoto() async {
    try {
      isLoading.value = true;
      hasGps.value = false;
      gpsError.value = '';

      final XFile? photo = await _picker.pickImage(
        source: ImageSource.camera,
        requestFullMetadata: true,
      );

      if (photo == null) {
        isLoading.value = false;
        return;
      }

      final File permanentFile = await _saveToPermanentPath(photo);
      capturedImage.value = permanentFile;

      // Run EXIF reading and GPS capture in parallel
      await Future.wait([_readExif(permanentFile.path), _captureGps()]);
    } catch (e) {
      gpsError.value = 'Error: $e';
    } finally {
      isLoading.value = false;
    }
  }

  Future<File> _saveToPermanentPath(XFile photo) async {
    final dir = await getApplicationDocumentsDirectory();
    final fileName = '${DateTime.now().millisecondsSinceEpoch}.jpg';
    final File localFile = File('${dir.path}/$fileName');
    await photo.saveTo(localFile.path);
    return localFile;
  }

  Future<void> _readExif(String path) async {
    try {
      final bytes = await File(path).readAsBytes();
      final rawTags = await exif_dart.readExifFromBytes(bytes);
      final displayAttrs = <String, Object>{};
      for (final entry in rawTags.entries) {
        displayAttrs[entry.key] = entry.value.printable;
      }
      allAttributes.value = displayAttrs;
    } catch (_) {}
  }

  Future<void> _captureGps() async {
    gpsLoading.value = true;
    try {
      final permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        final requested = await Geolocator.requestPermission();
        if (requested == LocationPermission.denied ||
            requested == LocationPermission.deniedForever) {
          gpsError.value = 'Location permission denied.';
          return;
        }
      }

      final LocationSettings settings = Platform.isAndroid
          ? AndroidSettings(
              accuracy: LocationAccuracy.bestForNavigation,
              forceLocationManager: true,
              timeLimit: const Duration(seconds: 15),
              intervalDuration: Duration.zero,
            )
          : const LocationSettings(
              accuracy: LocationAccuracy.bestForNavigation,
              timeLimit: Duration(seconds: 15),
            );

      final position = await Geolocator.getCurrentPosition(
        locationSettings: settings,
      );

      gpsLatitude.value = position.latitude;
      gpsLongitude.value = position.longitude;
      gpsAltitude.value = position.altitude;
      gpsAccuracy.value = position.accuracy;
      hasGps.value = true;
    } catch (e) {
      gpsError.value = 'GPS error: $e';
    } finally {
      gpsLoading.value = false;
    }
  }

  void clearImage() {
    capturedImage.value = null;
    allAttributes.value = {};
    gpsLatitude.value = 0.0;
    gpsLongitude.value = 0.0;
    gpsAltitude.value = 0.0;
    gpsAccuracy.value = 0.0;
    hasGps.value = false;
    gpsError.value = '';
  }
}
